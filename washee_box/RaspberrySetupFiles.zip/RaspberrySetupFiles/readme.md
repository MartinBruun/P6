# this is how to set this stuff up
run the setup.sh script